# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 11:55:08 2024

@author: Asus
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error


#Loading the dataset
df = pd.read_csv(r'C:/Users/Maheshreddy/Desktop/Course/Project_177/models/Raw Material1.csv')
df.isnull().sum()
metals = ['FN', 'Aluminium', 'Molybdenum', 'Vanadium', 'Graphite', 'Manganese', 'Fluorite']

# Four  Business moments
for i in metals:
    i_mean = df.loc[df['Metal Name'] == i, 'Price'].mean()
    i_median = df.loc[df['Metal Name'] == i, 'Price'].median()
    i_skew = df.loc[df['Metal Name'] == i, 'Price'].skew()
    i_kurtosis = df.loc[df['Metal Name'] == i, 'Price'].kurtosis()
    print('Mean of ' + i + ':', i_mean)
    print('Median of ' + i + ':', i_median)
    print('Skew of ' + i + ':', i_skew)
    print('Kurtosis of ' + i + ':', i_kurtosis)
    print('------------------')

# EDA - Visualizations

for metal in metals:
    metal_data = df[df['Metal Name'] == metal]
    plt.plot(metal_data['Month'], metal_data['Price'], label = metal)
    plt.xlabel('Month')
    plt.ylabel('Price')
    plt.title('Metal Prices Over Time')
    plt.legend()
    plt.xticks(rotation=45)
    plt.show()

metal_stats = df.groupby('Metal Name')['Price'].describe()
print(metal_stats)

# Histogram of metal prices

for metal in metals:
    metal_data = df[df['Metal Name'] == metal]
    plt.hist(metal_data['Price'], bins=20)
    plt.xlabel('Price')
    plt.ylabel('Frequency')
    plt.title(f'Distribution of {metal} Prices')
    plt.show()


#boxplot for the prices of each metal
for col in metals:
    # Create a new figure for each column
    plt.figure()
    
    # Filter rows based on the condition 'Metal Name == col' and plot boxplot
    plt.boxplot(df.loc[df['Metal Name'] == col, 'Price'])
    
    # Set title with the column name
    plt.title(col)
    
    # Show the plot
    plt.show()
len(df)
# Mean Imputation

# Create an empty DataFrame to store the preprocessed data for all metals
preprocessed_data = pd.DataFrame()

for metal in metals:
    metal_data = df[df['Metal Name'] == metal]
    mean = metal_data['Price'].mean()
    metal_data['Price'].fillna(mean, inplace=True)

    # Concatenate the preprocessed data for the current metal with the existing preprocessed data
    preprocessed_data = pd.concat([preprocessed_data, metal_data], ignore_index=True)
preprocessed_data.isnull().sum()
# Save the preprocessed data for all metals to a CSV file
preprocessed_data.to_csv("preprocessed_data_metals.csv", index=False)


''' Auto EDA '''

# 1. SweetViz
import sweetviz as sv
s= sv.analyze(preprocessed_data)
s.show_html()

# 2. Dtale
import dtale as dt
d = dt.show(preprocessed_data)
d.open_browser()

''' Model Building '''

# Spliting each metal into train and test sets
# Assuming your preprocessed data is stored in a variable called 'preprocessed_data'

train = pd.DataFrame()
test = pd.DataFrame()

metals = ['FN', 'Aluminium', 'Molybdenum', 'Vanadium', 'Graphite', 'Manganese', 'Fluorite']
# As the dataset consists of 7 metals together, Using for loop spliting each metal into 80% train and 20% test 
for metal in metals:
    metal_data = preprocessed_data[preprocessed_data['Metal Name'] == metal]  
    metal_train = metal_data.iloc[:int(0.8*len(metal_data))]  # 80% for training
    metal_test = metal_data.iloc[int(0.8*len(metal_data)):]  # 20% for testing
    train = train._append(metal_train)
    test = test._append(metal_test)
    
    
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.metrics import mean_absolute_percentage_error

# Define a function to calculate MAPE
def calculate_mape(y_true, y_pred):
    return mean_absolute_percentage_error(y_true, y_pred)

# Define a function to fit ARIMA model
def fit_arima(train, order):
    model = ARIMA(train, order=order)
    model_fit = model.fit()
    return model_fit

# Define a function to fit SARIMA model
def fit_sarima(train, order, seasonal_order):
    model = SARIMAX(train, order=order, seasonal_order=seasonal_order)
    model_fit = model.fit()
    return model_fit

# Define a function to fit Exponential Smoothing model
def fit_exponential(train, seasonal_periods):
    model = ExponentialSmoothing(train, seasonal_periods=seasonal_periods, trend='add', seasonal='add')
    model_fit = model.fit()
    return model_fit

# Define a function to decompose time series into trend, seasonal, and residual components
def decompose_time_series(series):
    decomposition = seasonal_decompose(series, model='additive')
    trend = decomposition.trend
    seasonal = decomposition.seasonal
    residual = decomposition.resid
    return trend, seasonal, residual

# Define a function to fit Multiplicative Seasonality model
def fit_multiplicative_seasonality(train, seasonal_periods):
    trend, seasonal, _ = decompose_time_series(train)
    model = ExponentialSmoothing(seasonal, seasonal_periods=seasonal_periods, trend=None, seasonal='mul')
    model_fit = model.fit()
    return model_fit

# Define a function to fit Additive Seasonality Quadratic Trend model
def fit_additive_seasonality_quadratic_trend(train, seasonal_periods):
    trend, seasonal, _ = decompose_time_series(train)
    time = np.arange(len(train))
    time_squared = time ** 2
    X = np.column_stack((time, time_squared))
    model = ExponentialSmoothing(seasonal, seasonal_periods=seasonal_periods, trend='add', damped=True, seasonal='add')
    model_fit = model.fit()
    return model_fit

# Define a function to fit Quadratic Trend model
def fit_quadratic_trend(train):
    time = np.arange(len(train))
    time_squared = time ** 2
    X = np.column_stack((time, time_squared))
    model = ExponentialSmoothing(train, trend='add', damped=True)
    model_fit = model.fit()
    return model_fit

# Defining a function to evaluate model performance using MAPE
def evaluate_model(model_fit, test):
    predictions = model_fit.forecast(len(test))
    mape = calculate_mape(test, predictions)
    return mape


# Initialize an empty DataFrame to store MAPE values
mape_df = pd.DataFrame(columns=['Model', 'MAPE'])

# Iterate over each metal and build models
for metal in metals:
    train_data = train[train['Metal Name'] == metal]['Price']
    test_data = test[test['Metal Name'] == metal]['Price']
    
    # ARIMA
    try:
        arima_model = fit_arima(train_data, order=(1,1,0))  # Example order, you can tune this
        arima_mape = evaluate_model(arima_model, test_data)
        mape_df = mape_df._append({'Model': 'ARIMA', 'MAPE': arima_mape}, ignore_index=True)
    except:
        print(f'ARIMA model failed for {metal}')
    
    # SARIMA
    try:
        sarima_model = fit_sarima(train_data, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))  # Example order, you can tune this
        sarima_mape = evaluate_model(sarima_model, test_data)
        mape_df = mape_df._append({'Model': 'SARIMA', 'MAPE': sarima_mape}, ignore_index=True)
    except:
        print(f'SARIMA model failed for {metal}')
    
    # Exponential Smoothing
    try:
        exp_model = fit_exponential(train_data, seasonal_periods=12)  # Example seasonal_periods, you can tune this
        exp_mape = evaluate_model(exp_model, test_data)
        mape_df = mape_df._append({'Model': 'Exponential', 'MAPE': exp_mape}, ignore_index=True)
    except:
        print(f'Exponential model failed for {metal}')
    
    # Multiplicative Seasonality
    try:
        mult_seasonality_model = fit_multiplicative_seasonality(train_data, seasonal_periods=12)  # Example seasonal_periods, you can tune this
        mult_seasonality_mape = evaluate_model(mult_seasonality_model, test_data)
        mape_df = mape_df._append({'Model': 'Multiplicative Seasonality', 'MAPE': mult_seasonality_mape}, ignore_index=True)
    except:
        print(f'Multiplicative Seasonality model failed for {metal}')
    
    # Additive Seasonality Quadratic Trend
    try:
        add_seasonality_quadratic_trend_model = fit_additive_seasonality_quadratic_trend(train_data, seasonal_periods=12)  # Example seasonal_periods, you can tune this
        add_seasonality_quadratic_trend_mape = evaluate_model(add_seasonality_quadratic_trend_model, test_data)
        mape_df = mape_df._append({'Model': 'Additive Seasonality Quadratic Trend', 'MAPE': add_seasonality_quadratic_trend_mape}, ignore_index=True)
    except:
        print(f'Additive Seasonality Quadratic Trend model failed for {metal}')
    
    # Quadratic Trend
    try:
        quadratic_trend_model = fit_quadratic_trend(train_data)
        quadratic_trend_mape = evaluate_model(quadratic_trend_model, test_data)
        mape_df = mape_df._append({'Model': 'Quadratic Trend', 'MAPE': quadratic_trend_mape}, ignore_index=True)
    except:
        print(f'Quadratic Trend model failed for {metal}')


# Print or further analyze mape_df
print(mape_df)


# Find the best model with the lowest MAPE
best_model_row = mape_df.loc[mape_df['MAPE'].idxmin()]

# Get the name of the best model
best_model_name = best_model_row['Model']

# Print the best model information
print("Best Model:", best_model_name)
print("MAPE:", best_model_row['MAPE'])

# Fit the best model again on the entire data
best_model = None
if best_model_name == 'ARIMA':
    best_model = fit_arima(train_data, order=(1,1,0))  # Use appropriate order
elif best_model_name == 'SARIMA':
    best_model = fit_sarima(train_data, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))  # Use appropriate orders
elif best_model_name == 'Exponential':
    best_model = fit_exponential(train_data, seasonal_periods=12)  # Use appropriate seasonal periods
elif best_model_name == 'Multiplicative Seasonality':
    best_model = fit_multiplicative_seasonality(train_data, seasonal_periods=12)  # Use appropriate seasonal periods
elif best_model_name == 'Additive Seasonality Quadratic Trend':
    best_model = fit_additive_seasonality_quadratic_trend(train_data, seasonal_periods=12)  # Use appropriate seasonal periods
elif best_model_name == 'Quadratic Trend':
    try:
        best_model = fit_quadratic_trend(train_data)
    except FutureWarning as fw:
        print(f"FutureWarning: {fw}")
        best_model = fit_quadratic_trend(train_data)
 # No additional parameters needed

# Plotting the comparison between train and test
plt.plot(train_data.index, train_data.values, label='Train Data')
plt.plot(test_data.index, test_data.values, label='Test Data')
if best_model is not None:
    predictions_train = best_model.predict(start=train_data.index[0], end=train_data.index[-1])
    predictions_test = best_model.predict(start=test_data.index[0], end=test_data.index[-1])
    plt.plot(train_data.index, predictions_train, label='Train Predictions')
    plt.plot(test_data.index, predictions_test, label='Test Predictions')
plt.xlabel('Time')
plt.ylabel('Price')
plt.title('Comparison between Train and Test Data with Predictions')
plt.legend()
plt.show()

# Save the best model
if best_model is not None:
    best_model.save('best_model.pkl')


# Predicting the next 12 months' prices
forecast = best_model.forecast(steps=6)

import pandas as pd
import numpy as np
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
import pickle

# Load the preprocessed data for all metals

# Define functions to fit models for each metal
def fit_exponential_model(data, metal_name):
    model = ExponentialSmoothing(data, seasonal_periods=12, trend='add', seasonal='add')
    model_fit = model.fit()
    with open(f'best_model_{metal_name}.pkl', 'wb') as f:
        pickle.dump(model_fit, f)

def fit_arima_model(data, metal_name):
    model = ARIMA(data, order=(1, 1, 0))
    model_fit = model.fit()
    with open(f'best_model_{metal_name}.pkl', 'wb') as f:
        pickle.dump(model_fit, f)

def fit_quadratic_model(data, metal_name):
    time = np.arange(len(data))
    time_squared = time ** 2
    X = np.column_stack((time, time_squared))
    model = ExponentialSmoothing(data, trend='add', damped=True)
    model_fit = model.fit()
    with open(f'best_model_{metal_name}.pkl', 'wb') as f:
        pickle.dump(model_fit, f)

# Iterate over each metal and fit the best model
best_models = {
    'FN': fit_exponential_model,
    'Aluminium': fit_arima_model,
    'Molybdenum': fit_exponential_model,
    'Vanadium': fit_arima_model,
    'Graphite': fit_quadratic_model,
    'Manganese': fit_quadratic_model,
    'Fluorite': fit_arima_model
}

for metal, model_function in best_models.items():
    metal_data = preprocessed_data[preprocessed_data['Metal Name'] == metal]['Price']
    model_function(metal_data, metal)
    best_model.save('best_model_{metal}.pkl')

# Iterate over each metal and predict the next 6 months' prices
forecast_df = pd.DataFrame(columns=['Month', 'Metal Name', 'Price'])
metals = ['FN', 'Aluminium', 'Molybdenum', 'Vanadium', 'Graphite', 'Manganese', 'Fluorite']
for metal in metals:
    # Load the best model for the current metal
    with open(f'best_model_{metal}.pkl', 'rb') as f:
        best_model = pickle.load(f)
    
    # Get the preprocessed data for the current metal
    current_metal_data = preprocessed_data[preprocessed_data['Metal Name'] == metal]['Price']
    
    # Predict the next 6 months' prices for the current metal using the loaded model
    forecast = best_model.forecast(steps=6)
    
    # Generate a date range for the next 6 months starting from Jan-24 to Jun-24
    next_6_months_dates = pd.date_range(start='2024-01-01', periods=6, freq='M')
    
    # Format the dates to display as "Month-Year"
    formatted_dates = [date.strftime('%b-%y') for date in next_6_months_dates]
    
    # Create a DataFrame for the current metal's forecasted prices
    metal_forecast_df = pd.DataFrame({'Month': formatted_dates, 'Metal Name': metal, 'Price': forecast})
    
    # Append the current metal's forecasted prices to the main DataFrame
    forecast_df = pd.concat([forecast_df, metal_forecast_df], ignore_index=True)


# Print the forecasted DataFrame
print(forecast_df)



# Print the best model information
print("Best Model:", best_model_name)
print("MAPE:", best_model_row['MAPE'])


# Print the forecasted DataFrame

