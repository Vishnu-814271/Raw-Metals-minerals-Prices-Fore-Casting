import streamlit as st
import pandas as pd
import numpy as np
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import pickle

# Define the function to load the trained model for a given metal
def load_model(metal_name):
    with open(f'C:/Users/Maheshreddy/Desktop/Course/Project_177/models/best_model_{metal_name}.pkl', 'rb') as f:
        model = pickle.load(f)
    return model

# Define the function to predict the next N months' prices for a given metal
def predict_next_N_months(metal_name, model, N):
    df = pd.read_csv(r"C:/Users/Maheshreddy/Desktop/Course/Project_177/models/preprocessed_data_metals.csv")
    # Filter data for the selected metal
    metal_data = df[df['Metal_Name'] == metal_name]['Price']
    # Predict the next N months' prices for the current metal
    forecast = model.forecast(steps=N)
    return forecast

# Define the metals
metals = ['FN', 'Aluminium', 'Molybdenum', 'Vanadium', 'Graphite', 'Manganese', 'Fluorite']

# Display a dropdown menu to select the metal
selected_metal = st.selectbox('Select Metal:', metals)

# Load the trained model for the selected metal
best_model = load_model(selected_metal)

# Input box for specifying the number of months for forecasting
forecast_months = st.number_input('Enter the number of months for forecasting:', min_value=1, max_value=24, value=6, step=1)

# Button to trigger the prediction process
if st.button('Predict'):
    # Predict the next N months' prices for the selected metal
    forecast = predict_next_N_months(selected_metal, best_model, forecast_months)

    # Generate a date range for the next N months starting from Jan-24 to N months later
    next_N_months_dates = pd.date_range(start='2024-01-01', periods=forecast_months, freq='M')

    # Format the dates to display as "Month-Year"
    formatted_dates = [date.strftime('%b-%y') for date in next_N_months_dates]

    # Create a DataFrame for the forecasted prices
    forecast_df = pd.DataFrame({'Month': formatted_dates, 'Metal_Name': selected_metal, 'Price': forecast})

    # Display the forecasted prices as a table
    st.table(forecast_df)
